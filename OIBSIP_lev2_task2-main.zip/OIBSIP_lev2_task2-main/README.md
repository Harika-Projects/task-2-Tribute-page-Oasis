# OIBSIP_lev2_task2
Tribute page on Mahatma Gandhi using HTML &amp; CSS
